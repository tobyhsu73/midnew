﻿﻿﻿Embedded Template Library (ETL)
-------------------------

![GitHub release (latest by date)](https://img.shields.io/github/v/release/ETLCPP/etl-arduino)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](https://opensource.org/licenses/MIT)
![CI](https://github.com/ETLCPP/etl/workflows/vs2019/badge.svg)
![CI](https://github.com/ETLCPP/etl/workflows/gcc/badge.svg)
![CI](https://github.com/ETLCPP/etl/workflows/clang/badge.svg)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/3c14cd918ccf40008d0bcd7b083d5946)](https://www.codacy.com/manual/jwellbelove/etl?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=ETLCPP/etl&amp;utm_campaign=Badge_Grade)

**This repository is an Arduino compatible clone of the Embedded Template Library (ETL)**

https://github.com/ETLCPP/etl

See (https://www.etlcpp.com/arduino.html) for up-to-date information.



